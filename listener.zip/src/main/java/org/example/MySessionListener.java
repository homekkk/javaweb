package org.example;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpSessionListener;
@WebListener
public class MySessionListener implements HttpSessionListener, ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext ctx = sce.getServletContext();
        ctx.setAttribute("totalVisits", 0);
        ctx.setAttribute("currentOnline", 0);
        System.out.println("Request counter initialized.");
    }

    public void addRequestCount(ServletRequestEvent requestEvent) {
        ServletContext ctx = requestEvent.getServletContext();
        int totalVisits = (int) ctx.getAttribute("totalVisits");
        int currentOnline = (int) ctx.getAttribute("currentOnline");

        ctx.setAttribute("totalVisits", totalVisits + 1);
        ctx.setAttribute("currentOnline", currentOnline + 1);
        System.out.println("New Request created. Total visits: " + (totalVisits + 1) + ", Current online: " + (currentOnline + 1));
    }
    public void deleteRequestCount(ServletRequestEvent requestEvent) {
        ServletContext ctx = requestEvent.getServletContext();
        int currentOnline = (int) ctx.getAttribute("currentOnline");

        ctx.setAttribute("currentOnline", currentOnline - 1);
        System.out.println("Request destroyed. Current online: " + (currentOnline - 1));
    }
}
