package org.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    //private static final long serialVersionUID=1;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //response.getWriter().write("Test Servlet Response");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 登录时候将用户名保存到session
        response.setContentType("text/html");
        response.setCharacterEncoding("utf-8");
        String name=request.getParameter("username");
        HttpSession session=request.getSession();
        response.getWriter().write("Test Servlet Response");
    }
}
