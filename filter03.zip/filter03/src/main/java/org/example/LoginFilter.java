package org.example;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@WebFilter(filterName = "LoginFilter",urlPatterns = "/*")
public class LoginFilter implements Filter {
    // 排除列表，不需要登录就能访问的路径
    private static final List<String> excludePaths = Arrays.asList("/","/login", "/register", "/index",
            "/index.jsp", "/login.jsp", "/register.jsp");

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;
        HttpSession session = request.getSession();
        // 获取请求的URI
        String requestURI = request.getRequestURI();
        System.out.println("URI：");
        System.out.println(requestURI);

        // 检查请求是否在排除列表中
        if (isExcluded(requestURI)) {
            System.out.println("路径：" + requestURI + "已放行");
            chain.doFilter(request, response);
        } else {
            // 检查用户是否已登录
            if (session != null && session.getAttribute("user") != null) {
                // 用户已登录，继续请求
                chain.doFilter(request, response);
            } else {
                // 用户未登录，重定向到登录页面
                response.sendRedirect(request.getContextPath() + "/login.jsp");
            }
        }
    }

    @Override
    public void destroy() {
        //Filter.super.destroy();
        // 在过滤器销毁时执行清理工作
    }
    /**
     * 检查当前请求路径是否在排除列表中
     * @param requestURI 当前请求的URI
     * @return 如果在排除列表中返回true，否则返回false
     */
    private boolean isExcluded(String requestURI) {
        /*for (String path : excludePaths) {
            if (requestURI.startsWith(path)) {
                return true;
            }
        }*/
        if (excludePaths.contains(requestURI)) {
            return true;
        }
        return false;
    }
}
